# Minecraft Android — V0.2

A small Android voxel sandbox prototype built with Java and OpenGL ES 2.0.

## V0.2 changes
- Rebuilt touch input: independent movement and camera-look pointers, with a fixed virtual joystick zone and a separate look zone.
- Added jump, crouch, gravity, grounded state, and basic player-vs-block collision.
- Added ray-based block targeting with a six-block reach for breaking and placing.
- Added selectable hotbar blocks: grass, dirt, stone, wood, and leaves.
- Expanded the world to 48×48 with rolling terrain, layered soil/stone, trees, and a small water feature.
- Added shader compile/link checks and safer frame-time handling.
- Added on-screen action controls and a compact HUD.

## Build
Open this project in Android Studio or run:

```bash
gradle --no-daemon :app:assembleDebug
```

The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Controls
- Left lower area: move
- Right area: look around
- JUMP / CROUCH: player movement
- BREAK / PLACE: target the block at the center of the screen
- Hotbar: choose the block type to place

This is still an early prototype, not a complete Minecraft replacement. World persistence, inventory, mobs, crafting, audio, and advanced rendering are not implemented yet.
