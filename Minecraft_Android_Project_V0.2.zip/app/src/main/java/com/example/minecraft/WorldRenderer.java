package com.example.minecraft;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.*;
import java.util.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class WorldRenderer implements GLSurfaceView.Renderer {
    private int program,pos,col,mvpLoc;
    private FloatBuffer vertices; private int vertexCount;
    private final float[] projection=new float[16],view=new float[16],mvp=new float[16],model=new float[16];
    private float px=16.5f,py=7.2f,pz=25.5f,yaw=0,pitch=-13;
    private final int[][][] blocks=new int[48][24][48];
    private boolean dirty=true,grounded=false,crouching=false;
    private float verticalVelocity=0,inputX=0,inputY=0,lastFrame=0;
    private int selectedBlock=1;
    private final Random random=new Random(2026);

    @Override public void onSurfaceCreated(GL10 gl,EGLConfig cfg){
        GLES20.glClearColor(.52f,.76f,.98f,1f);GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glEnable(GLES20.GL_CULL_FACE);
        program=makeProgram("attribute vec3 aPosition;attribute vec4 aColor;uniform mat4 uMVP;varying vec4 vColor;void main(){gl_Position=uMVP*vec4(aPosition,1.0);vColor=aColor;}","precision mediump float;varying vec4 vColor;void main(){gl_FragColor=vColor;}");
        pos=GLES20.glGetAttribLocation(program,"aPosition");col=GLES20.glGetAttribLocation(program,"aColor");mvpLoc=GLES20.glGetUniformLocation(program,"uMVP");generateWorld();buildMesh();lastFrame=System.nanoTime();
    }
    private int makeProgram(String vs,String fs){int v=shader(GLES20.GL_VERTEX_SHADER,vs),f=shader(GLES20.GL_FRAGMENT_SHADER,fs),p=GLES20.glCreateProgram();GLES20.glAttachShader(p,v);GLES20.glAttachShader(p,f);GLES20.glLinkProgram(p);int[] ok=new int[1];GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0);if(ok[0]==0)throw new RuntimeException("Shader link failed: "+GLES20.glGetProgramInfoLog(p));return p;}
    private int shader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);int[] ok=new int[1];GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0);if(ok[0]==0)throw new RuntimeException("Shader compile failed: "+GLES20.glGetShaderInfoLog(s));return s;}
    private void generateWorld(){
        for(int x=0;x<48;x++)for(int z=0;z<48;z++){
            double wave=Math.sin(x*.23)*1.6+Math.cos(z*.19)*1.4+Math.sin((x+z)*.11)*.8;
            int h=Math.max(2,Math.min(8,4+(int)Math.round(wave)));
            for(int y=0;y<=h;y++){if(y==h)blocks[x][y][z]=1;else if(y>h-4)blocks[x][y][z]=2;else blocks[x][y][z]=3;}
        }
        // Small forest patches with layered leaf canopies.
        for(int n=0;n<22;n++){int x=4+random.nextInt(40),z=4+random.nextInt(40),h=surface(x,z);if(h<4)continue;
            for(int y=h+1;y<=h+4&&y<22;y++)blocks[x][y][z]=4;
            for(int y=h+3;y<=h+5&&y<23;y++)for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++)if(Math.abs(dx)+Math.abs(dz)+(y==h+5?1:0)<=3&&inside(x+dx,y,z+dz)&&blocks[x+dx][y][z+dz]==0)blocks[x+dx][y][z+dz]=5;
        }
        // A shallow pond with a sandy edge.
        for(int x=27;x<34;x++)for(int z=8;z<14;z++){int h=surface(x,z);if((x-30)*(x-30)+(z-11)*(z-11)<8){blocks[x][h][z]=6;}}
    }
    private int surface(int x,int z){for(int y=22;y>=0;y--)if(blocks[x][y][z]!=0)return y;return 1;}
    private boolean inside(int x,int y,int z){return x>=0&&x<48&&y>=0&&y<24&&z>=0&&z<48;}
    private void buildMesh(){
        ArrayList<Float> out=new ArrayList<>(200000);
        float[][][] c={{{0,0,0},{1,0,0},{1,1,0},{0,1,0}},{{1,0,1},{0,0,1},{0,1,1},{1,1,1}},{{0,0,1},{0,0,0},{0,1,0},{0,1,1}},{{1,0,0},{1,0,1},{1,1,1},{1,1,0}},{{0,1,0},{1,1,0},{1,1,1},{0,1,1}},{{0,0,1},{1,0,1},{1,0,0},{0,0,0}}};
        int[][] dirs={{0,0,-1},{0,0,1},{-1,0,0},{1,0,0},{0,1,0},{0,-1,0}};int[] tri={0,1,2,0,2,3};
        for(int x=0;x<48;x++)for(int y=0;y<24;y++)for(int z=0;z<48;z++){int type=blocks[x][y][z];if(type==0)continue;
            for(int f=0;f<6;f++){int nx=x+dirs[f][0],ny=y+dirs[f][1],nz=z+dirs[f][2];if(inside(nx,ny,nz)&&blocks[nx][ny][nz]!=0)continue;
                float shade=f==4?1f:(f==5?.52f:.78f);float r,g,b;
                switch(type){case 1:r=.30f;g=.68f;b=.23f;break;case 2:r=.48f;g=.30f;b=.16f;break;case 3:r=.43f;g=.45f;b=.48f;break;case 4:r=.40f;g=.25f;b=.12f;break;case 5:r=.17f;g=.48f;b=.17f;break;default:r=.18f;g=.43f;b=.82f;break;}
                for(int k:tri){float[] p=c[f][k];out.add(x+p[0]);out.add(y+p[1]);out.add(z+p[2]);out.add(r*shade);out.add(g*shade);out.add(b*shade);out.add(1f);}
            }
        }
        float[] a=new float[out.size()];for(int i=0;i<a.length;i++)a[i]=out.get(i);vertices=ByteBuffer.allocateDirect(a.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();vertices.put(a).position(0);vertexCount=a.length/7;dirty=false;
    }
    @Override public void onSurfaceChanged(GL10 gl,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(projection,0,70f,(float)w/Math.max(1,h),.08f,120f);}
    @Override public void onDrawFrame(GL10 gl){long now=System.nanoTime();float dt=Math.min(.05f,(now-lastFrame)/1_000_000_000f);lastFrame=now;updatePhysics(dt);if(dirty)buildMesh();
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
        float yr=(float)Math.toRadians(yaw),pr=(float)Math.toRadians(pitch);float lx=(float)Math.sin(yr)*(float)Math.cos(pr),ly=(float)Math.sin(pr),lz=-(float)Math.cos(yr)*(float)Math.cos(pr);
        Matrix.setLookAtM(view,0,px,py,pz,px+lx,py+ly,pz+lz,0,1,0);Matrix.setIdentityM(model,0);Matrix.multiplyMM(mvp,0,view,0,model,0);Matrix.multiplyMM(mvp,0,projection,0,mvp,0);
        GLES20.glUseProgram(program);GLES20.glUniformMatrix4fv(mvpLoc,1,false,mvp,0);vertices.position(0);GLES20.glEnableVertexAttribArray(pos);GLES20.glEnableVertexAttribArray(col);GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,28,vertices);vertices.position(3);GLES20.glVertexAttribPointer(col,4,GLES20.GL_FLOAT,false,28,vertices);GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,vertexCount);GLES20.glDisableVertexAttribArray(pos);GLES20.glDisableVertexAttribArray(col);
    }
    private void updatePhysics(float dt){float speed=crouching?1.7f:4.2f;float a=(float)Math.toRadians(yaw);float vx=((float)Math.cos(a)*inputY+(float)Math.sin(a)*inputX)*speed*dt;float vz=((float)Math.sin(a)*inputY-(float)Math.cos(a)*inputX)*speed*dt;moveHorizontal(vx,vz);
        verticalVelocity-=19f*dt;float ny=py+verticalVelocity*dt;if(verticalVelocity<=0&&collides(px,ny-.15f,pz)){py=(float)Math.floor(ny-.15f)+1.16f;verticalVelocity=0;grounded=true;}else if(verticalVelocity>0&&collides(px,ny+.45f,pz)){verticalVelocity=0;}else{py=ny;grounded=false;}if(py<1.5f){py=1.5f;verticalVelocity=0;grounded=true;}
    }
    private void moveHorizontal(float dx,float dz){float nx=px+dx;if(!collides(nx,py-.95f,pz)&&nx>1&&nx<47)px=nx;float nz=pz+dz;if(!collides(px,py-.95f,nz)&&nz>1&&nz<47)pz=nz;}
    private boolean collides(float x,float y,float z){int minX=(int)Math.floor(x-.28f),maxX=(int)Math.floor(x+.28f),minZ=(int)Math.floor(z-.28f),maxZ=(int)Math.floor(z+.28f);int minY=(int)Math.floor(y),maxY=(int)Math.floor(y+1.65f);for(int bx=minX;bx<=maxX;bx++)for(int bz=minZ;bz<=maxZ;bz++)for(int by=minY;by<=maxY;by++)if(inside(bx,by,bz)&&blocks[bx][by][bz]!=0&&blocks[bx][by][bz]!=6)return true;return false;}
    public void setMoveInput(float x,float y){inputX=x;inputY=-y;}
    public void look(float dx,float dy){yaw+=dx;pitch=Math.max(-85,Math.min(85,pitch-dy));}
    public void jump(){if(grounded){verticalVelocity=7.4f;grounded=false;}}
    public void setCrouch(boolean b){crouching=b;}
    public void selectBlock(int id){selectedBlock=Math.max(1,Math.min(5,id));}
    private int[] raycast(){float yr=(float)Math.toRadians(yaw),pr=(float)Math.toRadians(pitch);float dx=(float)Math.sin(yr)*(float)Math.cos(pr),dy=(float)Math.sin(pr),dz=-(float)Math.cos(yr)*(float)Math.cos(pr);int lastX=-1,lastY=-1,lastZ=-1;for(float t=.2f;t<=6f;t+=.08f){int x=(int)Math.floor(px+dx*t),y=(int)Math.floor(py+dy*t),z=(int)Math.floor(pz+dz*t);if(!inside(x,y,z))continue;if(blocks[x][y][z]!=0)return new int[]{x,y,z,lastX,lastY,lastZ};lastX=x;lastY=y;lastZ=z;}return null;}
    public void breakBlock(){int[] hit=raycast();if(hit!=null){blocks[hit[0]][hit[1]][hit[2]]=0;dirty=true;}}
    public void placeBlock(){int[] hit=raycast();if(hit==null||hit[3]<0)return;int x=hit[3],y=hit[4],z=hit[5];if(inside(x,y,z)&&blocks[x][y][z]==0){if(Math.abs(x-px)<.8f&&Math.abs(z-pz)<.8f&&y>=py-1.8f&&y<=py+.2f)return;blocks[x][y][z]=selectedBlock;dirty=true;}}
}
