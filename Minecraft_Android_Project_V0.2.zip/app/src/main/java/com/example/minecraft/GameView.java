package com.example.minecraft;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class GameView extends GLSurfaceView {
    private final WorldRenderer renderer;
    private int movePointer=-1, lookPointer=-1;
    private float moveX,moveY,lastLookX,lastLookY;
    private boolean crouch=false;
    public GameView(Context c){super(c);setEGLContextClientVersion(2);renderer=new WorldRenderer();setRenderer(renderer);setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);}
    public void jump(){queueEvent(()->renderer.jump());}
    public void setCrouch(boolean b){crouch=b;queueEvent(()->renderer.setCrouch(b));}
    public void breakBlock(){queueEvent(()->renderer.breakBlock());}
    public void placeBlock(){queueEvent(()->renderer.placeBlock());}
    public void selectBlock(int id){queueEvent(()->renderer.selectBlock(id));}
    @Override public boolean onTouchEvent(MotionEvent e){
        int action=e.getActionMasked(), index=e.getActionIndex(), id=e.getPointerId(index);
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){float x=e.getX(index),y=e.getY(index);if(x<getWidth()*.42f&&y>getHeight()*.42f&&movePointer==-1){movePointer=id;moveX=x;moveY=y;}else if(lookPointer==-1){lookPointer=id;lastLookX=x;lastLookY=y;}return true;}
        if(action==MotionEvent.ACTION_MOVE){for(int i=0;i<e.getPointerCount();i++){int pid=e.getPointerId(i);float x=e.getX(i),y=e.getY(i);if(pid==movePointer){float dx=(x-moveX)/(getWidth()*.16f),dy=(y-moveY)/(getHeight()*.16f);float len=(float)Math.sqrt(dx*dx+dy*dy);if(len>1){dx/=len;dy/=len;}final float fx=dx,fy=dy;queueEvent(()->renderer.setMoveInput(fx,fy));}else if(pid==lookPointer){float dx=x-lastLookX,dy=y-lastLookY;lastLookX=x;lastLookY=y;final float fx=dx,fy=dy;queueEvent(()->renderer.look(fx*.22f,fy*.18f));}}return true;}
        if(action==MotionEvent.ACTION_POINTER_UP||action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){if(id==movePointer){movePointer=-1;queueEvent(()->renderer.setMoveInput(0,0));}if(id==lookPointer)lookPointer=-1;return true;}return true;
    }
}
