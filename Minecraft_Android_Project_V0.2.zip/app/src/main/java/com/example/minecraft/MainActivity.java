package com.example.minecraft;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.pm.ActivityInfo;

public class MainActivity extends Activity {
    private GameView game;
    private TextView status;
    private int selected = 1;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        FrameLayout root = new FrameLayout(this);
        game = new GameView(this);
        root.addView(game, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(18,7,18,7);
        top.setBackgroundColor(0x88000000);
        TextView title = label("MINECRAFT  •  SURVIVAL",15,true);
        top.addView(title,new LinearLayout.LayoutParams(0, -1, 1));
        status = label("DAY 1   |   GRASSLAND",11,false);
        top.addView(status);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1,42,Gravity.TOP);
        root.addView(top,tp);

        // Action buttons on the right; the uncovered right side remains the look zone.
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setGravity(Gravity.CENTER);
        actions.addView(action("JUMP", v -> game.jump()));
        actions.addView(action("CROUCH", v -> game.setCrouch(true), v -> game.setCrouch(false)));
        FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(94,-2,Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        ap.rightMargin=14; root.addView(actions,ap);

        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER);
        tools.addView(action("BREAK", v -> game.breakBlock()));
        tools.addView(action("PLACE", v -> game.placeBlock()));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2,48,Gravity.BOTTOM|Gravity.RIGHT);
        bp.rightMargin=14; bp.bottomMargin=14; root.addView(tools,bp);

        LinearLayout hotbar = new LinearLayout(this);
        hotbar.setGravity(Gravity.CENTER);
        hotbar.setPadding(5,4,5,4);
        hotbar.setBackgroundColor(0x99000000);
        String[] blocks={"GRASS","DIRT","STONE","WOOD","LEAF"};
        for(int i=0;i<blocks.length;i++){
            final int id=i+1;
            TextView slot=label(blocks[i],10,true);
            slot.setGravity(Gravity.CENTER);
            slot.setPadding(9,10,9,10);
            slot.setBackground(bg(i==0?0xFF6C9C45:0xFF303030,0xFFBBBBBB));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,42); lp.setMargins(3,0,3,0); hotbar.addView(slot,lp);
            slot.setOnClickListener(v->{selected=id;game.selectBlock(id);slot.setBackground(bg(0xFF6C9C45,0xFFFFFFFF));});
        }
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        hp.bottomMargin=12; root.addView(hotbar,hp);
        setContentView(root);
    }

    private TextView label(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable bg(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(9);d.setStroke(2,stroke);return d;}
    private TextView action(String text, View.OnClickListener click){TextView t=label(text,11,true);t.setGravity(Gravity.CENTER);t.setPadding(10,12,10,12);t.setBackground(bg(0xCC222222,0xFFAAAAAA));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,42);p.setMargins(3,4,3,4);t.setOnClickListener(click);t.setLayoutParams(p);return t;}
    private TextView action(String text, View.OnClickListener down, View.OnClickListener up){TextView t=action(text,down);t.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){down.onClick(v);return true;}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){up.onClick(v);return true;}return true;});return t;}
    @Override protected void onPause(){super.onPause();if(game!=null)game.onPause();}
    @Override protected void onResume(){super.onResume();if(game!=null)game.onResume();}
}
