# Minecraft (working title) — Android voxel prototype

A clean-room Android voxel sandbox starter built with Java and OpenGL ES 2.0. It uses original placeholder visuals and code; it does not include Mojang/Minecraft proprietary assets or code.

## Current prototype
- Landscape Android app
- OpenGL ES 2.0 renderer
- Procedurally generated 32×32 block terrain
- First-person camera look
- Basic touch movement
- Basic break/place test actions
- GitHub Actions debug APK workflow

## Build
Open this project in Android Studio or push it to a GitHub repository. The workflow at `.github/workflows/main.yml` builds a debug APK on pushes to `main` or via Actions → Build Minecraft Android APK → Run workflow.

This is an early foundation, not a finished Minecraft replacement. Inventory, crafting, chunk streaming, collision, mobs, save/load, audio and polished touch controls are not implemented yet.
