package com.example.minecraft;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.opengl.GLSurfaceView;
import android.content.pm.ActivityInfo;

public class MainActivity extends Activity {
    private GameView game;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        FrameLayout root = new FrameLayout(this);
        game = new GameView(this);
        root.addView(game);
        LinearLayout hud = new LinearLayout(this);
        hud.setOrientation(LinearLayout.HORIZONTAL);
        hud.setGravity(Gravity.CENTER_VERTICAL);
        hud.setPadding(18,10,18,10);
        hud.setBackgroundColor(0x55000000);
        TextView title = new TextView(this);
        title.setText("  MINECRAFT  •  SURVIVAL TEST");
        title.setTextColor(Color.WHITE); title.setTextSize(14);
        hud.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView hint = new TextView(this);
        hint.setText("DRAG: LOOK     LEFT: MOVE     BREAK / PLACE");
        hint.setTextColor(0xFFE6E6E6); hint.setTextSize(11);
        hud.addView(hint);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, 48, Gravity.TOP);
        root.addView(hud, hp);
        setContentView(root);
    }
    @Override protected void onPause(){ super.onPause(); if(game!=null) game.onPause(); }
    @Override protected void onResume(){ super.onResume(); if(game!=null) game.onResume(); }
}
