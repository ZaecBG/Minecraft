package com.example.minecraft;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.*;
import java.util.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class WorldRenderer implements GLSurfaceView.Renderer {
    private int program, pos, col, mvpLoc;
    private FloatBuffer vertices;
    private int vertexCount;
    private final float[] projection=new float[16], view=new float[16], mvp=new float[16], model=new float[16];
    private float px=16, py=4, pz=25, yaw=0, pitch=-12;
    private final int[][][] blocks=new int[32][12][32];
    private boolean dirty=true;

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig cfg) {
        GLES20.glClearColor(0.52f,0.75f,0.95f,1f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_CULL_FACE);
        program=makeProgram(
          "attribute vec3 aPosition; attribute vec4 aColor; uniform mat4 uMVP; varying vec4 vColor; void main(){gl_Position=uMVP*vec4(aPosition,1.0);vColor=aColor;}",
          "precision mediump float; varying vec4 vColor; void main(){gl_FragColor=vColor;}");
        pos=GLES20.glGetAttribLocation(program,"aPosition");
        col=GLES20.glGetAttribLocation(program,"aColor");
        mvpLoc=GLES20.glGetUniformLocation(program,"uMVP");
        generateWorld(); buildMesh();
    }
    private int makeProgram(String vs,String fs){
        int v=shader(GLES20.GL_VERTEX_SHADER,vs), f=shader(GLES20.GL_FRAGMENT_SHADER,fs);
        int p=GLES20.glCreateProgram(); GLES20.glAttachShader(p,v); GLES20.glAttachShader(p,f); GLES20.glLinkProgram(p); return p;
    }
    private int shader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);return s;}
    private void generateWorld(){
        Random r=new Random(17);
        for(int x=0;x<32;x++) for(int z=0;z<32;z++){
            int h=2+(int)(Math.sin(x*.35)*1.2+Math.cos(z*.28)*1.2)+(r.nextInt(3)==0?1:0);
            h=Math.max(1,Math.min(5,h));
            for(int y=0;y<h;y++) blocks[x][y][z]=(y==h-1?1:2);
        }
        // Small tree cluster
        for(int x=7;x<10;x++) for(int z=7;z<10;z++) blocks[x][5][z]=3;
        for(int y=3;y<7;y++) blocks[8][y][8]=4;
    }
    private void buildMesh(){
        ArrayList<Float> out=new ArrayList<>();
        float[][][] corners={{{0,0,0},{1,0,0},{1,1,0},{0,1,0}},{{1,0,1},{0,0,1},{0,1,1},{1,1,1}},{{0,0,1},{0,0,0},{0,1,0},{0,1,1}},{{1,0,0},{1,0,1},{1,1,1},{1,1,0}},{{0,1,0},{1,1,0},{1,1,1},{0,1,1}},{{0,0,1},{1,0,1},{1,0,0},{0,0,0}}};
        int[][] dirs={{0,0,-1},{0,0,1},{-1,0,0},{1,0,0},{0,1,0},{0,-1,0}};
        for(int x=0;x<32;x++)for(int y=0;y<12;y++)for(int z=0;z<32;z++)if(blocks[x][y][z]!=0){
            int type=blocks[x][y][z];
            for(int f=0;f<6;f++){
                int nx=x+dirs[f][0],ny=y+dirs[f][1],nz=z+dirs[f][2];
                if(nx>=0&&nx<32&&ny>=0&&ny<12&&nz>=0&&nz<32&&blocks[nx][ny][nz]!=0)continue;
                float shade=f==4?1f:(f==5?.55f:.78f);
                float rr=type==1?.28f:type==2?.42f:type==3?.32f:.48f;
                float gg=type==1?.68f:type==2?.28f:type==3?.55f:.30f;
                float bb=type==1?.25f:type==2?.12f:type==3?.22f:.16f;
                int[] tri={0,1,2,0,2,3};
                for(int idx:tri){float[] c=corners[f][idx];out.add(x+c[0]);out.add(y+c[1]);out.add(z+c[2]);out.add(rr*shade);out.add(gg*shade);out.add(bb*shade);out.add(1f);}
            }
        }
        float[] a=new float[out.size()];for(int i=0;i<a.length;i++)a[i]=out.get(i);
        vertices=ByteBuffer.allocateDirect(a.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();vertices.put(a).position(0);vertexCount=a.length/7;dirty=false;
    }
    @Override public void onSurfaceChanged(GL10 gl,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(projection,0,70f,(float)w/h,.1f,100f);}
    @Override public void onDrawFrame(GL10 gl){
        if(dirty)buildMesh();
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
        float yr=(float)Math.toRadians(yaw), pr=(float)Math.toRadians(pitch);
        float lx=(float)Math.sin(yr)*(float)Math.cos(pr), ly=(float)Math.sin(pr), lz=-(float)Math.cos(yr)*(float)Math.cos(pr);
        Matrix.setLookAtM(view,0,px,py,pz,px+lx,py+ly,pz+lz,0,1,0);
        Matrix.setIdentityM(model,0);Matrix.multiplyMM(mvp,0,view,0,model,0);Matrix.multiplyMM(mvp,0,projection,0,mvp,0);
        GLES20.glUseProgram(program);GLES20.glUniformMatrix4fv(mvpLoc,1,false,mvp,0);
        vertices.position(0);GLES20.glEnableVertexAttribArray(pos);GLES20.glEnableVertexAttribArray(col);
        vertices.position(0);GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,28,vertices);
        vertices.position(3);GLES20.glVertexAttribPointer(col,4,GLES20.GL_FLOAT,false,28,vertices);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,vertexCount);
        GLES20.glDisableVertexAttribArray(pos);GLES20.glDisableVertexAttribArray(col);
    }
    public void look(float dx,float dy){yaw+=dx;pitch=Math.max(-80,Math.min(80,pitch+dy));}
    public void move(float dx,float dy){float a=(float)Math.toRadians(yaw);px+=(float)Math.cos(a)*dx+(float)Math.sin(a)*dy;pz+=(float)Math.sin(a)*dx-(float)Math.cos(a)*dy;px=Math.max(1,Math.min(30,px));pz=Math.max(1,Math.min(30,pz));}
    public void breakBlock(){int x=Math.round(px),z=Math.round(pz),y=Math.max(0,Math.min(11,(int)py-1));if(x>=0&&x<32&&z>=0&&z<32&&blocks[x][y][z]!=0){blocks[x][y][z]=0;dirty=true;}}
    public void placeBlock(){int x=Math.round(px+ (float)Math.sin(Math.toRadians(yaw))*2),z=Math.round(pz-(float)Math.cos(Math.toRadians(yaw))*2),y=Math.max(1,Math.min(10,(int)py-1));if(x>=0&&x<32&&z>=0&&z<32&&blocks[x][y][z]==0){blocks[x][y][z]=1;dirty=true;}}
}
