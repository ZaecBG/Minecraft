package com.example.minecraft;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class GameView extends GLSurfaceView {
    private final WorldRenderer renderer;
    private float lastX, lastY;
    private int active = -1;
    public GameView(Context c) {
        super(c);
        setEGLContextClientVersion(2);
        renderer = new WorldRenderer();
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
    @Override public boolean onTouchEvent(MotionEvent e) {
        float x=e.getX(), y=e.getY();
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                active=e.getPointerId(0); lastX=x; lastY=y;
                if (y > getHeight()*0.68f && x > getWidth()*0.72f) {
                    if (x > getWidth()*0.86f) renderer.placeBlock(); else renderer.breakBlock();
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx=x-lastX, dy=y-lastY;
                if (lastX < getWidth()*0.34f && lastY > getHeight()*0.45f) {
                    renderer.move(dx/getWidth()*5f, dy/getHeight()*5f);
                } else {
                    renderer.look(dx*0.35f, dy*0.25f);
                }
                lastX=x; lastY=y; return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: active=-1; return true;
        }
        return true;
    }
}
